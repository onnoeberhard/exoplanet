AndroidPDFViewerLibrary
=======================

Example:
http://stackoverflow.com/questions/8814758/need-help-to-convert-a-pdf-page-into-bitmap-in-android-java/16294833#16294833
